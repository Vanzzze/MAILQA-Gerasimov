public class globalVariables {
    public static int allLines = 0;
    public static int filteredLines = 0;

    public globalVariables(int allLines, int filteredLines) {
        this.allLines = allLines;
        this.filteredLines = filteredLines;
    }

    public int getAllLines() {
        return allLines;
    }

    public void setAllLines(int allLines) {
        this.allLines = allLines;
    }

    public int getFilteredLines() {
        return filteredLines;
    }

    public void setFilteredLines(int filteredLines) {
        this.filteredLines = filteredLines;
    }
}
